﻿Public Class FrmMaterias
    Private Sub BtnAcc_Click(sender As Object, e As EventArgs) Handles BtnAcc.Click
        Me.Close()
    End Sub
End Class